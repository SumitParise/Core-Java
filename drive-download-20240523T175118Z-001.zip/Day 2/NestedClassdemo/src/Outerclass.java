
public class Outerclass {
	private int x;
	static class InnerClass{
		public void method2() {
			System.out.println("in method");
		}
	}

}
