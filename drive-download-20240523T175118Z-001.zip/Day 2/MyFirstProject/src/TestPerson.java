import java.util.Date;
public class TestPerson {

	public static void main(String[] args) {
		Person p=new Person("Revati","5555",new Date());
		System.out.println(p);
		Person p1=new Person("Rajan","6666",new Date());
		System.out.println(p1);
	
	}

}
