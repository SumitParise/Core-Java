package com.demo.interfaces;

public interface I4 {
void m41();
void m42();
}
