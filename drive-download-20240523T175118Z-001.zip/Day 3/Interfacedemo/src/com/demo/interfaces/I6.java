package com.demo.interfaces;

public interface I6 extends I4,I5{
   void m61();
   protected int m3();
}
